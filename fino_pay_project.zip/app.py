
from flask import Flask, jsonify, request
import telegram

app = Flask(__name__)

# إعداد بوت التليجرام
TELEGRAM_TOKEN = '1927846651:AAFs6vxlBGk2cy82LVJWZp4_8yoEiohw96o'
CHAT_ID = '709989970'
bot = telegram.Bot(token=TELEGRAM_TOKEN)

users = {
    "user1": {"balance": 100, "subscription": False, "blocked": False}
}

@app.route('/add_balance', methods=['POST'])
def add_balance():
    username = request.json.get('username')
    amount = request.json.get('amount')
    if username in users:
        users[username]['balance'] += amount
        bot.send_message(chat_id=CHAT_ID, text=f"تم إضافة رصيد: {amount} للمستخدم {username}")
        return jsonify({"message": "تم الإضافة", "new_balance": users[username]['balance']})
    return jsonify({"message": "المستخدم غير موجود"}), 404

@app.route('/toggle_subscription', methods=['POST'])
def toggle_subscription():
    username = request.json.get('username')
    if username in users:
        users[username]['subscription'] = not users[username]['subscription']
        status = "مفعّل" if users[username]['subscription'] else "معطّل"
        bot.send_message(chat_id=CHAT_ID, text=f"تم {status} الاشتراك للمستخدم {username}")
        return jsonify({"message": f"تم {status} الاشتراك"})
    return jsonify({"message": "المستخدم غير موجود"}), 404

@app.route('/block_user', methods=['POST'])
def block_user():
    username = request.json.get('username')
    if username in users:
        users[username]['blocked'] = True
        bot.send_message(chat_id=CHAT_ID, text=f"تم حظر المستخدم {username} من الإيداع")
        return jsonify({"message": "تم الحظر"})
    return jsonify({"message": "المستخدم غير موجود"}), 404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8000)
